// TUTOR HUDSON STEM CONCEPT WEBSITE
import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

const App = () => (
  <Router>
    <header style={{ background: '#0070f3', color: 'white', padding: '10px' }}>
      <h1>Tutor Hudson STEM Concept</h1>
      <nav>
        <Link to="/">Home</Link> | <Link to="/about">About</Link> | <Link to="/photos">Photos</Link>
      </nav>
    </header>
    <main style={{ padding: '20px' }}>
      <Routes>
        <Route path="/" element={<div>Welcome to STEM Teaching Hub!</div>} />
        <Route path="/about" element={<div>About Tutor Hudson</div>} />
        <Route path="/photos" element={<div>Photo Gallery Coming Soon...</div>} />
      </Routes>
    </main>
  </Router>
);

export default App;
